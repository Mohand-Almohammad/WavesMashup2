# Verteilte Systeme Projektarbeit Gruppe 16

## Autoren: 

Mohand Almohammad,
Matrikelnummer: 10012449

Samr Alakrad,
Matrikelnummer: 10013285

Romuald Ngongang Djugouo,
Matrikelnummer: 10013531

Leif Plewe,
Matrikelnummer: 10004565

