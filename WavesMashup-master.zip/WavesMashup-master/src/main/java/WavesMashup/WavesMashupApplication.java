package WavesMashup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WavesMashupApplication {

	public static void main(String[] args) {
		SpringApplication.run(WavesMashupApplication.class, args);
	}

}
