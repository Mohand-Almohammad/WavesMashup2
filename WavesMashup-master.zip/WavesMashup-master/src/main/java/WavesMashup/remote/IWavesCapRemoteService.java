package WavesMashup.remote;

import WavesMashup.remote.views.WavePriceView;

public interface IWavesCapRemoteService {
  WavePriceView getWaves();
}
