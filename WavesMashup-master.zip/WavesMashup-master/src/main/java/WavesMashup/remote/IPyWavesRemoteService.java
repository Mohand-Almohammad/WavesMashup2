package WavesMashup.remote;

import WavesMashup.remote.views.PyWavesInterestOverview;

public interface IPyWavesRemoteService {
  PyWavesInterestOverview getWavesInterest();

}
