package WavesMashup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WavesMashupApplicationTests {

	@Test
	void contextLoads() {
	}

}
