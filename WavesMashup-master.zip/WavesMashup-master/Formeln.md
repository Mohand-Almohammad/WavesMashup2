# Moving Average

d = Tage für die das MA berechnet werden soll

p(x) = LastPrice an Tag x

### SMA(d) = (p(1)+ p(2) + ... + p(d)) / d 



## Examples
7 Day Simple Moving Average SMA(7) = (p(1)+p(2)+p(3)+p(4)+p(5)+p(6)+p(7)) / 7

21 Day Simple Moving Average SMA(21) = (p(1)+p(2)+...+ p(21)) / 21
